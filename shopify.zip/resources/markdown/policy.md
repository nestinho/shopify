# Privacy Policy

Edit this file to define the privacy policy for your application.
