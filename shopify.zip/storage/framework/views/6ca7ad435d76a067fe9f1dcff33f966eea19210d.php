<div>
    <div class="container" style="padding: 30px 0;">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-6">
                                Edit Product
                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('admin.products')); ?>" class="btn btn-success pull-right">View All Products</a>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <?php if(Session::has('message')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(Session::get('message')); ?>

                        </div>
                        <?php endif; ?>
                        <form class="form-horizontal" enctype="multipart/form-data" wire:submit.prevent="updateProduct">
                            <div class="form-group">
                                <label for="product_name" class="col-md-4 control-label">Product Name</label>
                                <div class="col-md-4">
                                    <input class="form-control input-md" type="text" wire:model="name" wire:keyup="generateSlug" placeholder="Product Name" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="product_slug" class="col-md-4 control-label">Product Slug</label>
                                <div class="col-md-4">
                                    <input class="form-control input-md" type="text" wire:model="slug" placeholder="Product Slug" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="short_description" class="col-md-4 control-label">Short Description</label>
                                <div class="col-md-4">
                                   <textarea class="form-control" placeholder="Short description" wire:model="short_description"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="description" class="col-md-4 control-label">Description</label>
                                <div class="col-md-4">
                                   <textarea class="form-control" placeholder="Description" wire:model="description"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="regular_price" class="col-md-4 control-label">Regular Price</label>
                                <div class="col-md-4">
                                    <input class="form-control input-md" type="number" name="regular_price" wire:model="regular_price" placeholder="Regular Price" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="sale_price" class="col-md-4 control-label">Sale Price</label>
                                <div class="col-md-4">
                                    <input class="form-control input-md" type="number" name="sale_price" wire:model="sale_price" placeholder="Sale Price" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="SKU" class="col-md-4 control-label">SKU</label>
                                <div class="col-md-4">
                                    <input class="form-control input-md" type="text" name="SKU" wire:model="SKU" placeholder="SKU" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="instock_status" class="col-md-4 control-label">In Stock Status</label>
                                <div class="col-md-4">
                                    <select class="form-control">
                                        <option value="instock">In Stock</option>
                                        <option value="outofstock">Out of Stock</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="instock_status" class="col-md-4 control-label">Featured</label>
                                <div class="col-md-4">
                                    <select class="form-control" wire:model="featured">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="quantity" class="col-md-4 control-label">Quantity</label>
                                <div class="col-md-4">
                                    <input class="form-control input-md" type="number" name="quantity" wire:model="quantity" placeholder="Quantity" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="image" class="col-md-4 control-label">Product Image</label>
                                <div class="col-md-4">
                                    <input class="input-file" type="file" wire:model="newimage"/><br/>
                                    <?php if($newimage): ?>
                                        <img src="<?php echo e($newimage->temporaryUrl()); ?>" width="120" />
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($image); ?>" width="120" />
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="image" class="col-md-4 control-label">Product Gallery</label>
                                <div class="col-md-4">
                                    <input class="input-file" type="file" wire:model="newimages" multiple/><br/>
                                    <?php if($newimages): ?>
                                        <?php $__currentLoopData = $newimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newimage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($newimage): ?>
                                                <img src="<?php echo e($newimage->temporaryUrl()); ?>" width="120" />
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($image): ?>
                                                <img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($image); ?>" width="120" />
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="instock_status" class="col-md-4 control-label">Category</label>
                                <div class="col-md-4">
                                    <select class="form-control" wire:model="category_id">
                                        <option value="">-- Select Category --</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="category_name" class="col-md-4 control-label"></label>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-info">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\shopify\resources\views/livewire/admin/admin-edit-product-component.blade.php ENDPATH**/ ?>