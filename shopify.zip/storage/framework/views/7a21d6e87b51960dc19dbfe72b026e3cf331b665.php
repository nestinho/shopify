<div>
    <style>
        nav svg{
            height: 20px;
        }

        nav .hidden{
            display: block !important;
        }

        .sub-category-list{
            list-style: none;
        }
    </style>

    <div class="container" style="padding: 30px 0;">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-6">
                                All Attributes
                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('admin.add_attribute')); ?>" class="btn btn-success pull-right">Add New Attribute</a>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(Session::get('message')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('delete_success_message')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(Session::get('delete_success_message')); ?>

                            </div>
                        <?php endif; ?>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#.</th>
                                    <th>Name</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $product_attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($product_attribute->id); ?></td>
                                    <td><?php echo e($product_attribute->name); ?></td>
                                    <td><?php echo e($product_attribute->created_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.edit_attribute',['attribute_id'=>$product_attribute->id])); ?>"><i class="fa fa-edit fa-2x"></i></a>
                                        <a href="#" onclick="return confirm('Are you sure you want to delete this attribute?') || event.StopImmediatePropagation()" wire:click.prevent="deleteAttribute(<?php echo e($product_attribute->id); ?>)" style="margin-left: 10px;"><i class="fa fa-trash fa-2x text-danger"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($product_attributes->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\shopify\resources\views/livewire/admin/admin-attributes-component.blade.php ENDPATH**/ ?>