<div>
    <div class="container" style="padding: 30px 0;">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-6">
                                <strong>All Slides</strong>
                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('admin.addhomeslider')); ?>" class="btn btn-success pull-right"><i class="fa fa-plus"></i>Add New Slider</a>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('message')); ?>

                            </div>
                        <?php endif; ?>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Image</th>
                                    <th>Title</th>
                                    <th>Subtitle</th>
                                    <th>Price</th>
                                    <th>Link</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($slider->id); ?></td>
                                        <td><img src="<?php echo e(asset('assets/images/sliders')); ?>/<?php echo e($slider->image); ?>" width="120"/></td>
                                        <td><?php echo e($slider->title); ?></td>
                                        <td><?php echo e($slider->subtitle); ?></td>
                                        <td><?php echo e($slider->price); ?></td>
                                        <td><?php echo e($slider->link); ?></td>
                                        <td><?php echo e($slider->status == 1 ? 'Active':'Inactive'); ?></td>
                                        <td><?php echo e($slider->created_at); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.edithomeslider',['slider_id'=>$slider->id])); ?>" class="btn btn-primary"><i class="fa fa-edit"></i></a>
                                            <a href="#" onclick="return confirm('Are you sure to delete this home slide?')" wire:click.prevent="deleteSlide(<?php echo e($slider->id); ?>)" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>  
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\shopify\resources\views/livewire/admin/admin-home-slider-component.blade.php ENDPATH**/ ?>